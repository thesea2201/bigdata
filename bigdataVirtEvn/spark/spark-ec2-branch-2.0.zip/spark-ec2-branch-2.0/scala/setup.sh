#!/bin/bash

/root/spark-ec2/copy-dir /root/scala
